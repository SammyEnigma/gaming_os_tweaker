if (!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
	Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`"" -Verb RunAs; exit
}

Push-Location $PSScriptRoot

Get-Acl .\nvcplui.exe

icacls * /t /q /c /reset
icacls * /grant administrators:F /T
takeown /f * /r /d y

Get-Acl .\nvcplui.exe

cmd /c pause